# GitHub Practice #
###### This is a private project being utilized to practice using GitHub for a non-techincal user. ######
